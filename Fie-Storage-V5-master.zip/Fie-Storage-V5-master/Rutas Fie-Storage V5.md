**User:**

<task>
s
</task>
<environment_details>
# VSCode Visible Files
src/components/FolderNavigation.tsx

# VSCode Open Tabs
src/utils/storage.ts
src/pages/Dashboard.tsx
src/components/FolderNavigation.tsx

# Current Working Directory (c:/Users/Ezequiel/Desktop/Fie-storage salvado/Fie-Storage-V5) Files
.gitignore
eslint.config.js
index.html
package-lock.json
package.json
postcss.config.js
Rutas Fie-Storage V5.md
tailwind.config.js
tsconfig.app.json
tsconfig.json
tsconfig.node.json
vite.config.ts
src/
src/App.tsx
src/index.css
src/main.tsx
src/types.ts
src/vite-env.d.ts
src/components/
src/components/ActivityHistory.tsx
src/components/AdminFilters.tsx
src/components/Breadcrumb.tsx
src/components/CommentModal.tsx
src/components/ContentPanel.tsx
src/components/ErrorBoundary.tsx
src/components/FileActivity.tsx
src/components/FileCard.tsx
src/components/FileUploadButton.tsx
src/components/Filters.tsx
src/components/FolderCard.tsx
src/components/FolderManagementDialog.tsx
src/components/FolderNavigation.tsx
src/components/Navbar.tsx
src/components/PrivateRoute.tsx
src/components/ProfileDialog.tsx
src/components/ProfileHeader.tsx
src/components/Sidebar.tsx
src/components/UserManagement.tsx
src/contexts/
src/contexts/AuthContext.tsx
src/lib/
src/lib/firebase.ts
src/pages/
src/pages/Dashboard.tsx
src/pages/FileUpload.tsx
src/pages/FileView.tsx
src/pages/FolderPage.tsx
src/pages/Login.tsx
src/pages/Profile.tsx
src/pages/Register.tsx
src/utils/
src/utils/folderCrud.ts
src/utils/storage.ts
</environment_details>

